<?php


require_once ('config/config.php');
require_once ('config/access.php');
require_once ('config/routes.php');
require_once ('config/locale.php');
require_once ('config/libs.conf.php');
require_once (COREPATH .'helper.php');
require_once (COREPATH .'common.php');
require_once (COREPATH .'class_messages.php');
require_once (COREPATH .'class_db.php');
require_once (COREPATH .'class_session.php');
require_once (LIBS . 'smarty/Smarty.class.php');
require_once (COREPATH .'application.php');
require_once (COREPATH .'controller.php');

?>
